<?php

require __DIR__.'../../vendor/autoload.php';

use App\Handler\Blog;
use App\Router;


$router = new Router();

$router->get('/', function (array $params){
    echo "Home page";
    echo $params['id'];
});

// $router->get('/blog', Blog::class . '::execute' );

$router->get('/blog', function ($params){
    require_once '../views/blog.php';
});
$router->post('/blog', function ($params){
    var_dump($params);
});

$router->HandlerNotFound(function (){
    echo "Non trouvé";
});

$router->run();

?>