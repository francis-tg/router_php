<?php

namespace App\Handler;

class Blog 
{
    function execute()
    {
        echo "Valid";
    }
}



?>