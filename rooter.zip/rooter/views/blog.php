

<form method="post">
<div class="form-group">
  <label for=""></label>
  <input type="text" class="form-control" name="name" id="" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>
<div class="form-group">
  <label for=""></label>
  <input type="text" class="form-control" name="lname" id="" aria-describedby="helpId" placeholder="">
  <small id="helpId" class="form-text text-muted">Help text</small>
</div>
 <button type="submit" class="btn btn-primary btn-sm">Small button</button>
 

</form>